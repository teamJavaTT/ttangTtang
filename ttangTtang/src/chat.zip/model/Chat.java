package chat.model;

public class Chat {
	private String UserId;
	private String UserText;
}
